package com.example.week4vp

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape

import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.week4vp.R // Change this to your actual package

@Composable
fun PartyRosterScreen() {
    // Colors based on the UI
    val bgColor = Color(0xFF0F121C)
    val cardColor = Color(0xFF1E1F2E)
    val yellowAccent = Color(0xFFFFC107)

    // Dummy Data
    val heroes = remember {
        mutableStateListOf(
            Hero(1, "Alistair", "MYTHIC", "High Templar", 5600, 50, 1650, 1800, 650, 800, 380, 540, "22%", 105, "Wrath of the Heavens", "Calls down a celestial hammer, stunning all enemies for 3 seconds and taunting survivors."),
            Hero(2, "Theresa", "MYTHIC", "Divine Oracle", 5480, 49, 1100, 1200, 2100, 2400, 210, 300, "15%", 110, "Holy Light", "Heals all allies by 500 HP."),
            Hero(3, "Vespera", "MYTHIC", "Shadowblade", 5350, 48, 890, 950, 410, 600, 450, 200, "45%", 130, "Assassinate", "Deals massive damage to a single target."),
            Hero(4, "Elaria", "MYTHIC", "Archmage", 5120, 47, 450, 600, 1950, 2000, 500, 150, "30%", 100, "Meteor Strike", "Calls down a meteor on enemies.", inSquad = true)
        )
    }

    // Filter Logic State
    val filters = listOf("All (14)", "Berserker (2)", "Archmage (3)", "Support (4)")
    var selectedFilter by remember { mutableStateOf(filters[0]) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(bgColor)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- HEADER SECTION ---
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(text = "Party Roster", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Bold)
                    Text(text = "Guild Vanguard • 14 Heroes Available", color = Color.Gray, fontSize = 12.sp)
                }

                Surface(
                    color = Color.Transparent,
                    border = BorderStroke(1.dp, yellowAccent),
                    shape = RoundedCornerShape(20.dp)
                ) {
                    Text(
                        text = "★ Expedition",
                        color = yellowAccent,
                        fontSize = 12.sp,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }
            }
        }

        // --- EXPEDITION SQUAD BOX ---
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = cardColor),
                border = BorderStroke(1.dp, yellowAccent),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(modifier = Modifier.size(8.dp).clip(CircleShape).background(Color.Green))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("EXPEDITION SQUAD (3/4)", color = Color.Gray, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                        Text("⚔ 14750 CP", color = yellowAccent, fontWeight = FontWeight.Bold)
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Dummy avatars for squad
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            SquadAvatarBox(R.drawable.ic_launcher_background) // replace with actual images
                            SquadAvatarBox(R.drawable.ic_launcher_background)
                            SquadAvatarBox(R.drawable.ic_launcher_background)

                            // Empty slot box
                            Box(
                                modifier = Modifier
                                    .size(50.dp)
                                    .background(Color(0xFF2C2F42), RoundedCornerShape(8.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("+", color = Color.Gray, fontSize = 24.sp)
                            }
                        }

                        Button(
                            onClick = { },
                            colors = ButtonDefaults.buttonColors(containerColor = yellowAccent),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text("Deploy ⚡", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // --- SEARCH BAR ---
        item {
            OutlinedTextField(
                value = "",
                onValueChange = {},
                placeholder = { Text("Search by hero name, class, or rarity...", color = Color.Gray) },
                leadingIcon = {  Image(
                    painter = painterResource(id = R.drawable.searchyes),
                    contentDescription = "Search",
                    modifier = Modifier.size(20.dp)
                ) },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    unfocusedContainerColor = cardColor,
                    unfocusedBorderColor = Color.Transparent
                )
            )
        }

        // --- HORIZONTAL FILTERS ---
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(filters) { filter ->
                    val isSelected = selectedFilter == filter
                    Surface(
                        color = if (isSelected) Color(0xFF3B3521) else cardColor, // Yellow-ish tint if selected
                        border = if (isSelected) BorderStroke(1.dp, yellowAccent) else BorderStroke(1.dp, Color.Transparent),
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier.clickable { selectedFilter = filter }
                    ) {
                        Text(
                            text = filter,
                            color = if (isSelected) yellowAccent else Color.Gray,
                            modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
                            fontSize = 14.sp
                        )
                    }
                }

                // Sort Button at the end
                item {
                    Text(
                        text = "Sort: Power",
                        color = yellowAccent,
                        modifier = Modifier
                            .background(cardColor, RoundedCornerShape(16.dp))
                            .padding(horizontal = 16.dp, vertical = 8.dp),
                        fontSize = 14.sp
                    )
                }
            }
        }

        // --- HERO LIST ---
        items(heroes) { hero ->
            HeroCard(
                hero = hero,
                onCardClick = {
                    // Toggle expanded state (Bonus)
                    val index = heroes.indexOf(hero)
                    heroes[index] = hero.copy(isExpanded = !hero.isExpanded)
                }
            )
        }
    }
}

@Composable
fun HeroCard(hero: Hero, onCardClick: () -> Unit) {
    TODO("Not yet implemented")
}

// Helper for the squad images
@Composable
fun SquadAvatarBox(imageRes: Int) {
    Image(
        painter = painterResource(id = imageRes),
        contentDescription = null,
        modifier = Modifier
            .size(50.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(Color.White)
    )
}