package com.example.week4vp

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Preview(showBackground = true, showSystemUi = true)
@Composable
fun PartyRosterScreenPreview() {
    MaterialTheme {
        PartyRosterScreen()
    }
}

@Preview(showBackground = true)
@Composable
fun HeroCardPreview() {
    val dummyHero = Hero(
        id = 1,
        name = "Alistair",
        rarity = "MYTHIC",
        heroClass = "High Templar",
        cp = 5600,
        level = 50,
        currentHp = 1650,
        maxHp = 1800,
        currentMp = 650,
        maxMp = 800,
        atk = 380,
        def = 540,
        crit = "22%",
        spd = 105,
        skillName = "Wrath of the Heavens",
        skillDesc = "Calls down a celestial hammer, stunning all enemies for 3 seconds and taunting survivors.",
        inSquad = false,
        isExpanded = true // Diset true supaya dropdown stat langsung kelihatan di preview
    )

    MaterialTheme {
        HeroesCard(hero = dummyHero, onCardClick = {})
    }
}

@Composable
fun HeroesCard(hero: Hero, onCardClick: () -> Unit) {
    val cardColor = Color(0xFF1E1F2E)
    val yellowAccent = Color(0xFFFFC107)

    Card(
        colors = CardDefaults.cardColors(containerColor = cardColor),
        shape = RoundedCornerShape(16.dp),
        border = if (hero.inSquad) BorderStroke(1.dp, yellowAccent) else null, // Yellow border if in squad
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onCardClick() }
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // TOP ROW: Tags & CP
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    BadgeTag(text = hero.rarity, color = Color(0xFFE91E63)) // Red Mythic Tag
                    BadgeTag(text = hero.heroClass, color = if (hero.heroClass == "Shadowblade") Color(0xFF9C27B0) else Color(0xFF4CAF50))
                }

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("⚔ ${hero.cp} CP", color = yellowAccent, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    if (hero.inSquad) {
                        Spacer(modifier = Modifier.width(8.dp))
                        BadgeTag(text = "IN SQUAD", color = yellowAccent, textColor = Color.Black)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // MAIN INFO ROW
            Row(verticalAlignment = Alignment.CenterVertically) {
                // Avatar with Level Badge
                Box {
                    Image(
                        painter = painterResource(id = R.drawable.ic_launcher_background), // Replace with character image
                        contentDescription = hero.name,
                        modifier = Modifier
                            .size(70.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(Color.White)
                    )

                    // Level box overlapping bottom right
                    Surface(
                        color = Color(0xFF2C2F42),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.align(Alignment.BottomEnd)
                    ) {
                        Text(
                            text = "Lvl ${hero.level}",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(16.dp))

                // Name & Health/Mana Bars
                Column(modifier = Modifier.weight(1f)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(text = hero.name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)

                        // Expand/Collapse Icon
                        Image(
                            painter = painterResource(
                                id = if (hero.isExpanded) R.drawable.uparrow else R.drawable.downarrow
                            ),
                            contentDescription = "Expand",
                            modifier = Modifier.size(24.dp) // Icons handle their own sizing, but Images require explicit sizing
                        )

                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // HP Bar (Bonus)
                    StatBar(
                        label = "HP",
                        current = hero.currentHp,
                        max = hero.maxHp,
                        color = Color(0xFFE91E63) // Red for HP
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    // MP Bar (Bonus)
                    StatBar(
                        label = "MP",
                        current = hero.currentMp,
                        max = hero.maxMp,
                        color = Color(0xFF2196F3) // Blue for MP
                    )
                }
            }

            // --- EXPANDED DETAILS (Bonus) ---
            if (hero.isExpanded) {
                Spacer(modifier = Modifier.height(16.dp))
                Divider(color = Color.DarkGray)
                Spacer(modifier = Modifier.height(16.dp))

                // Stats Grid
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    StatBox("ATK", hero.atk.toString(), Color(0xFFE91E63))
                    StatBox("DEF", hero.def.toString(), Color(0xFF4CAF50))
                    StatBox("CRIT", hero.crit, Color(0xFFFFC107))
                    StatBox("SPD", hero.spd.toString(), Color(0xFF03A9F4))
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Skill Info
                Text(text = "★ ${hero.skillName}", color = yellowAccent, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Text(text = hero.skillDesc, color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(top = 4.dp))

                Spacer(modifier = Modifier.height(16.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    OutlinedButton(
                        onClick = { },
                        border = BorderStroke(1.dp, Color.DarkGray),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("🪄 Heal (+250 HP)", color = Color(0xFF4CAF50))
                    }

                    Button(
                        onClick = { },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF3B3521)),
                        border = BorderStroke(1.dp, yellowAccent),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("⚔ Add to Squad", color = yellowAccent)
                    }
                }
            }
        }
    }
}

// Helper for the small rarity/class badges
@Composable
fun BadgeTag(text: String, color: Color, textColor: Color = color) {
    Surface(
        color = color.copy(alpha = 0.1f), // Faded background
        border = BorderStroke(1.dp, color),
        shape = RoundedCornerShape(6.dp)
    ) {
        Text(
            text = text.uppercase(),
            color = textColor,
            fontSize = 9.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

// Helper for the dynamic Progress Bars (Bonus)
@Composable
fun StatBar(label: String, current: Int, max: Int, color: Color) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(text = label, color = Color.Gray, fontSize = 12.sp, modifier = Modifier.width(24.dp))

        // Custom thick progress bar
        Box(
            modifier = Modifier
                .weight(1f)
                .height(8.dp)
                .clip(RoundedCornerShape(4.dp))
                .background(Color(0xFF2C2F42))
        ) {
            Box(
                modifier = Modifier
                    .fillMaxHeight()
                    .fillMaxWidth(fraction = current.toFloat() / max.toFloat()) // Logic depending on value
                    .background(color)
            )
        }

        Spacer(modifier = Modifier.width(8.dp))
        Text(text = "$current / $max", color = Color.Gray, fontSize = 12.sp)
    }
}

// Helper for the 4 stat boxes in expanded view
@Composable
fun StatBox(title: String, value: String, color: Color) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .background(Color(0xFF2C2F42), RoundedCornerShape(8.dp))
            .padding(horizontal = 16.dp, vertical = 8.dp)
    ) {
        Text(text = title, color = color, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(text = value, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
    }
}