package com.example.week4vp

data class Hero(
    val id: Int,
    val name: String,
    val rarity: String,
    val heroClass: String,
    val cp: Int,
    val level: Int,
    val currentHp: Int,
    val maxHp: Int,
    val currentMp: Int,
    val maxMp: Int,
    val atk: Int,
    val def: Int,
    val crit: String,
    val spd: Int,
    val skillName: String,
    val skillDesc: String,
    val inSquad: Boolean = false,
    var isExpanded: Boolean = false
)